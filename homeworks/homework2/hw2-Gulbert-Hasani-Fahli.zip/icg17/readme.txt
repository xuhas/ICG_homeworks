Homework 2

exercice1:

the exercice one was done by using what was learned in the last exercice. The projection matrix used was found in the slides


exercices2:

For this exercice, we inspired ourselves with the reference given in the pdf and the queations given.

exercice 3:

The hardest part of this exercice was to find an algorithm to make the indices. The wave function was straight-forward.



